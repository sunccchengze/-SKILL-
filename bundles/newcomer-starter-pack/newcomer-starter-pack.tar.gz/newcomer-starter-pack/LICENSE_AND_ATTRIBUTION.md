# License and attribution

Each packaged skill retains the source path and source identifier recorded in MANIFEST.json. The bundle does not replace upstream licenses or grant additional rights. Consult THIRD_PARTY_NOTICE.md, the package-local legal files, and the identified source repository before redistribution or high-risk use.
